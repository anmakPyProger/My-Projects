import pygame
import random

pygame.init()

file = open('assets/best.txt')

screen = pygame.display.set_mode((1300,600))
time = pygame.time.Clock()
font = pygame.font.Font('assets/SometypeMono-Regular.ttf', 40)
icon = pygame.image.load('assets/icon.png')
pygame.display.set_caption('Snake by Makar A   version 1.6')
pygame.display.set_icon(icon)

player = {
    'x': 50,
    'y': 0,
    'desc': pygame.image.load('assets/head.png')
}

direction = 1
fps = int(input('Enter FPS value:'))

sound_1 = pygame.mixer.Sound('assets/upali-dengi-na-igrovoy-schet.mp3')
sound_2 = pygame.mixer.Sound('assets/opoveschenie-o-proigryishe.mp3')

cord = [(0,0)]
apple = pygame.Surface((50,50))
apple.fill('Red')
pos_a = (500,500)
score = 0
count = 0
best = int(file.read())
file.close()

part = {
    'desc': pygame.Surface((50,50))
}

part['desc'].fill('Green')
snake = [player,part]
gp = True
run = True

print('\nConsole:')
while run:

    key = pygame.key.get_pressed()
    
    if gp:
        if key[pygame.K_RIGHT] and direction != 2:
            direction = 1
        if key[pygame.K_LEFT] and direction != 1:
            direction = 2
        if key[pygame.K_DOWN] and direction != 4:
            direction = 3
        if key[pygame.K_UP] and direction != 3:
            direction = 4
    
        sc = (player['x'], player['y'])
        cord.insert(0, sc)

        if direction == 1:
            player['x'] += 50
        if direction == 2:
            player['x'] -= 50
        if direction == 3:
            player['y'] += 50
        if direction == 4:
            player['y'] -= 50

        screen.fill('Black')
        c = 0
        scrd = []   

        for el in snake:
            screen.blit(el['desc'],cord[c])
            scrd.append(cord[c])
            c += 1
        c = 0
        del scrd[0]

        if (player['x'],player['y']) == pos_a:
            snake.append(part)
            score += 1
            sound_1.play(0)
            print('Apple was eaten.')
            while True:
                pos_a =(random.randrange(0,1000,50),random.randrange(0,600,50))
                if pos_a in scrd:
                    continue
                else: break

        score_label = font.render(f'Score:{score}', False, 'White')
        score_best = font.render(f'Best:{best}', False, 'White')
        screen.blit(score_label, (1020,200))
        screen.blit(score_best, (1020,250))
        screen.blit(apple,pos_a)
        pygame.draw.rect(screen, 'White',(1000,0,10,600))
        pygame.display.update()
        if (player['x'],player['y']) in scrd or player['x'] > 950 or player['x'] < 0 or player['y'] > 550 or player['y'] < 0:
            gp = False
            sound_2.play(0)
            print('Lose!')
            if score > best:
                best = score
                file = open('assets/best.txt', mode='w')
                file.write(f'{best}')
                file.close()
                loose4 = font.render('New best! Cool!', False, 'Green')
            else: loose4 = font.render('', False, 'White')
    else:
        screen.fill((66, 135, 245))
        loose = font.render('You lose! Press Space to restart.', False, 'White')
        loose2 = font.render(f'Score:{score}', False, 'White')
        screen.blit(loose4, (350, 400))
        loose3 = font.render(f'Best:{best}', False, 'White')
        screen.blit(loose3,(350,350))
        screen.blit(loose,(300,250))
        screen.blit(loose2,(350,300))
        if key[pygame.K_SPACE]:
            gp = True
            snake = [player,part]
            cord = [(0,0)]
            player['x'] = 0
            player ['y'] = 0
            direction = 1
            pos_a = (500,500)
            score = 0
        pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            run = False
    time.tick(fps)