Hi!
You can change any files you want! 
Main file is |snake.py|
And if a file won't run, try running it through the console or run it until it works. 
These are PyGame bugs!

1.6 changes:
	= Best record saves!